﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SS2019
{
    internal class Aufgabe1
    {
        public static bool PWCheck(String password)
        {

            bool laengeRichtig = password.Length >= 12;
            bool einGross = false;
            bool eineZahl = false;
            foreach (char c in password)
            {
                if (c >= 'A' && c <= 'Z')
                {
                    einGross = true;
                }
                else if (c >= '0' && c <= '9')
                {
                    eineZahl = true;
                }
            }
            bool correct = laengeRichtig && einGross && eineZahl;
            return correct;
        }
    }
}
