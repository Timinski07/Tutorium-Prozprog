﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SS2019
{
    internal class Aufgabe2
    {
        public static int[,] ZeileLöschen(int[,] arr2D, int zeile)
        {
            if (zeile - 1 < arr2D.GetLength(0))
            {
                int[,] neuArr = new int[arr2D.GetLength(0) - 1, arr2D.GetLength(1)];
                for (int i = 0; i < neuArr.GetLength(0); ++i)
                {
                    for (int j = 0; j < neuArr.GetLength(1); ++j)
                    {
                        if (i != zeile - 1)
                        {
                            neuArr[i, j] = arr2D[i, j];
                        }
                        else
                        {
                            neuArr[i, j] = arr2D[i + 1, j];
                        }
                    }
                }
                return neuArr;
            }
            else
            {
                throw new ArgumentOutOfRangeException();
            }
        }
    }
}
