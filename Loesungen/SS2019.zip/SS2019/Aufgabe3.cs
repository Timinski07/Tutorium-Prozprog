﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SS2019
{
    enum LVArt { Vorlesung, Uebung, Seminar }
    class LehrVeranst
    {
        String fach;
        String raum;
        public String semgruppe;
        LVArt art;
        int id;
        static int fortId;
        public LehrVeranst(String f, String r, String s, LVArt lArt = LVArt.Vorlesung)
        {
            fach = f;
            raum = r;
            semgruppe = s;
            art = lArt;
            id = fortId++;
        }
        public int ID
        {
            get
            {
                return id;
            }
        }
        public static bool Kollision(LehrVeranst lv1, LehrVeranst lv2)
        {
            bool dasselbe = lv1.ID == lv2.ID;
            bool selberRaum = lv1.raum == lv2.raum;
            bool selbeGrup = lv1.semgruppe == lv2.semgruppe;
            return !dasselbe && (selbeGrup || selberRaum);
        }
    }
}
