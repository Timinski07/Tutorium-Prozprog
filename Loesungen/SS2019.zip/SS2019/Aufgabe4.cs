﻿using System;
using System.IO;

namespace SS2019
{
    internal class Aufgabe4
    {
        public static String BestFit(String raumart, int anzahl)
        {
            try// gehört nicht zur Aufgabe
            {
                //Aufgabe...
                StreamReader s = new StreamReader("C:/das/ist/ein/pfad");//hier den Pfad zu der .txt angeben
                String line = s.ReadLine();
                String besterRaum = null;
                while (line != null)
                {
                    String[] raum = line.Split(';');
                    if (raum[1] == raumart && anzahl <= Convert.ToInt32(raum[2]))
                    {
                        besterRaum = raum[0];
                    }
                    line = s.ReadLine();
                }
                s.Close();
                return besterRaum;
                //...
            }
            catch(Exception e)//gehört nicht zur Aufgabe
            {
                Console.WriteLine("funktioniert nicht: gib den Pfad zu deiner .txt datei im Code zu Aufgabe 4 ein");
                return null;
            }
        }
        
    }
}
