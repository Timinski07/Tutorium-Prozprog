﻿using System;

namespace SS2019
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Aufgabe 1
            Console.WriteLine("'allesodernix' als passwort gueltig: " + Aufgabe1.PWCheck("allesodernix"));
            Console.WriteLine("'allesOderNix' als passwort gueltig: " + Aufgabe1.PWCheck("allesOderNix"));
            Console.WriteLine("'allesOderNix089' als passwort gueltig: " + Aufgabe1.PWCheck("allesOderNix089"));
            Console.WriteLine("\n Weiter zu Aufgabe 2? (Enter)");
            Console.ReadKey();
            Console.Clear();
            //Aufgabe 2
            void print2Darr(int[,] arr2D)
            {
                for (int i = 0; i < arr2D.GetLength(0); ++i)
                {
                    for (int j = 0; j < arr2D.GetLength(1); ++j)
                    {
                        Console.Write(arr2D[i, j] + " ");
                    }
                    Console.WriteLine();
                }
            }
            int[,] arr2D = { { 1, 2, 3 }, { 4, 5, 6}, { 7, 8, 9} };
            print2Darr(arr2D);
            arr2D = Aufgabe2.ZeileLöschen(arr2D, 2);
            Console.WriteLine("\nnach Löschen:\n");
            print2Darr(arr2D);

            Console.WriteLine("\n Weiter zu Aufgabe 3? (Enter)");
            Console.ReadKey();
            Console.Clear();
            //Aufgabe 3
            LehrVeranst Win = new LehrVeranst("Prozprog", "HQ105", "Informatik");
            LehrVeranst IN = new LehrVeranst("Mathe", "HQ106", "Informatik");
            Console.WriteLine("Kollision verursacht?: " + LehrVeranst.Kollision(Win, IN));
            Console.WriteLine("\n Weiter zu Aufgabe 4? (Enter)");
            Console.ReadKey();
            Console.Clear();
            //Aufgabe 4
            Console.WriteLine("Bestfit: " + Aufgabe4.BestFit("Hoersaal", 30));

        }
    }
}
