﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiSe2015
{
    internal class Aufgabe1
    {public static String RemoveBlanks(String s)
        {
            String newS = "";
            for (int i = 0; i < s.Length; ++i)
            {
                if (s[i] != ' ')
                {
                    newS += s[i];
                }
                else if (s[i] == ' ' && s[i + 1] != ' ')
                {
                    newS += s[i];
                }
            }
            return newS;
        }
    }
}
