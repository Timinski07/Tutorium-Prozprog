﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiSe2015
{
    internal class Aufgabe2
    {
        static void anzahlSchilder()
        {
            //Aufagabe 2
            int[] schildZahlen = new int[10];
            for (int i = 0; i <= 3250; ++i)
            {
                int tmp = i;
                while (tmp > 0)
                {
                    int last = tmp % 10;
                    ++schildZahlen[last];
                    tmp = (tmp / 10);
                }

            }
            for (int j = 0; j < schildZahlen.Length; ++j)
            {
                Console.Write($"{schildZahlen[j]}x{j}  ");
            }
        }
    }
}
