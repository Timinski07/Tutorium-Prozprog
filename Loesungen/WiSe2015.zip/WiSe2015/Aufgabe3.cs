﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiSe2015
{
    internal class Aufgabe3
    {
    }
    enum MTyp { Angestellter, Gruppenleiter, Abteilungsleiter }
    class Person
    {
        String name;
        double gehalt;
        MTyp typ;
        int PersNr;
        static int persNrZaehler;
        public int NaechstePersNr
        {
            get { return persNrZaehler; }
            set
            {
                if (value >= persNrZaehler)
                {
                    PersNr = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }
        public Person(string name, double gehalt, MTyp typ, int persNr = -1)
        {
            this.name = name;
            this.gehalt = gehalt;
            this.typ = typ;
            if (persNr == -1)
            {
                PersNr = persNrZaehler++;
            }
            else
            {
                NaechstePersNr = persNr;
            }
        }
        public static double gehaltVolumen(Person[] Mitarbeiter, MTyp typ)
        {
            double gesamtGehalt = 0;
            foreach (Person mit in Mitarbeiter)
            {
                if (mit.typ == typ)
                {
                    gesamtGehalt = gesamtGehalt + mit.gehalt;
                }
            }
            return gesamtGehalt;
        }
    }
}
