﻿using System;
using System.IO;

namespace WiSe2015
{
    internal class Aufgabe4
    {
        public static double kundenUmsatz(String Kundennummer)
        {
            double umsatz = 0;
            StreamReader s = new StreamReader("C:\\stream\\Zeiterfassung.txt");
            String line = s.ReadLine();
            while (line != null)
            {
                String[] data = line.Split(" ");
                if (Kundennummer == data[0])
                {
                    String[] anfangsZeiten = data[2].Split(":");
                    String[] endZeiten = data[3].Split(":");

                    if (data.Length == 4)
                    {
                        int gesamtZeit = 60 - Convert.ToInt32(anfangsZeiten[1]);//Minuten, die bis zur ersten vollen Stunde vergingen
                        gesamtZeit = gesamtZeit + (((Convert.ToInt32(endZeiten[0]) - Convert.ToInt32(anfangsZeiten[0])) * 60));// alle vollen Stunden, welche zwischen der Anfangs und Endzeit angebrochen wurden
                        gesamtZeit = gesamtZeit - (60 - Convert.ToInt32(endZeiten[1]));// Minuten, welche zur letzten vollen Stunde fehlen
                        Console.WriteLine(gesamtZeit);
                        double geld = gesamtZeit / 15 * 0.4;
                        if (gesamtZeit % 15 != 0)
                        {
                            geld += 0.4;
                        }
                        umsatz += geld;
                    }
                }
                line = s.ReadLine();
            }
            return umsatz;
        }
    }
}
