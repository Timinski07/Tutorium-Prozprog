﻿using System;

namespace WiSe2015
{
    internal class Program
    {
        public static void Main(String[] args) {
            //Beispielprogramm für Aufgabe 4
            Person[] Mitarbeiter = { new Person("Max", 1400, MTyp.Angestellter), new Person("Dax", 2400, MTyp.Angestellter), new Person("Lachs", 3400, MTyp.Abteilungsleiter) };
            Console.WriteLine(Person.gehaltVolumen(Mitarbeiter, MTyp.Angestellter));
            Console.WriteLine(Aufgabe4.kundenUmsatz("K125"));
            //Rest selbst testen...
        }
    }
   
}
